    <table border="1">
        <thead>
		     <tr><th colspan="8"><a href="<?php echo site_url()?>export/createxls">Export Data</a></th></tr>
            <tr>
                <th>Name</th>
                <th>Phone</th>                           
                <th>Email</th>                      
                <th>Status</th>
				<th>Postal Address</th>
				<th>Parmanent Address</th>
				<th>Dept Title</th>
				<th>Dept Manager</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($employeeInfo) && !empty($employeeInfo)) {
                foreach ($employeeInfo as $key => $element) {
                    ?>
                    <tr>
                        <td><?php echo $element['name']; ?></td>   
                        <td><?php echo $element['phone']; ?></td> 
                        <td><?php echo $element['email']; ?></td>                       
                        <td><?php echo $element['status']; ?></td>
						<td><?php echo $element['employee_postal_address']; ?></td>
						<td><?php echo $element['employee_permanent_address']; ?></td>
						<td><?php echo $element['department_title']; ?></td>
						<td><?php echo $element['department_manager']; ?></td>
                    </tr>
                    <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="8">There is no employee.</td>    
                </tr>
            <?php } ?>
 
        </tbody>
    </table>
    
