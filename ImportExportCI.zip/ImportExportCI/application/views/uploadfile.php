<p><?php echo $this->session->flashdata('statusMsg'); ?></p>
<form method="post" action="" enctype="multipart/form-data">
        <input type="file" name="files[]" multiple/><br/><br/>
        <input type="submit" name="fileSubmit" value="UPLOAD"/>
</form>

<!-- display uploaded images -->
        <?php if(!empty($files)){ foreach($files as $file){ ?>
        <table border='1'>
		<tr>
		<td><img src="<?php echo base_url('uploads/files/'.$file['file_name']); ?>" width='50px;' height='50px;' ></td>
		<td>Uploaded On <?php echo date("j M Y",strtotime($file['uploaded_on'])); ?></td>
		</tr>
         <?php } }else{ ?>
        <tr><td>No Record</td></tr>
        <?php } ?>
		<table>
