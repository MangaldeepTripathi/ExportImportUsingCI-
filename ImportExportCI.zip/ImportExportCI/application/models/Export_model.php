<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Export_model extends CI_Model {
    // get employee list
    /*public function employeeList() {
        $this->db->select(array('e.id', 'e.first_name', 'e.last_name', 'e.email', 'e.dob', 'e.contact_no'));
        $this->db->from('import as e');
        $query = $this->db->get();
        return $query->result_array();
    }*/
	
	public function employeeList() {
        $this->db->select(array('e.id', 'e.name', 'e.phone', 'e.email', 'e.status','a.employee_postal_address','a.employee_permanent_address', 'd.department_title', 'd.department_manager'));
        $this->db->from('table_employee as e');
		$this->db->join('table_employee_address as a','e.id=a.emp_id','inner');
		$this->db->join('table_employee_department as d','e.id=d.emp_id','inner');
        $query = $this->db->get();
        return $query->result_array();
    }
}
?>