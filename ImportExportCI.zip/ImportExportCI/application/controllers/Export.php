<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Export extends CI_Controller {
	// construct
    public function __construct() {
        parent::__construct();
		// load model
        $this->load->model('Export_model', 'export');
		$this->load->library('excel');
    }    
	 // export xlsx|xls file
    public function index() {
        $data['page'] = 'export-excel';
        $data['title'] = 'Export Excel data | Mangal';
        $data['employeeInfo'] = $this->export->employeeList();
		// load view file for output
        $this->load->view('export/index', $data);
    }
	// create xlsx
    public function createXLS() {
		// create file name
        $fileName = 'data-'.time().'.xlsx';  
		// load excel library
        $this->load->library('excel');
        $empInfo = $this->export->employeeList();
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Header
        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Name');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Phone');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Email');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Status');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Postal Address');
        $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Parmanent Address');
        $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Dept Title');
        $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Dept Manager');		
        // set Row
        $rowCount = 2;
        foreach ($empInfo as $element) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $element['name']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $element['phone']);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $element['email']);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $element['status']);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $element['employee_postal_address']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $element['employee_permanent_address']);
			$objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $element['department_title']);
			$objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $element['department_manager']);
            $rowCount++;
        }		
		  $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
          $objWriter->save($fileName);
          // download file
          header("Content-Type: application/vnd.ms-excel");
          redirect(site_url().$fileName);  
    }
    
}
?>