-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2019 at 11:07 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mangal`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `file_name`, `uploaded_on`, `status`) VALUES
(1, 'beauty-bloom-blue-67636.jpg', '2019-04-18 08:35:41', '1'),
(2, 'BEE-1096-Fashion_Banners_01_preview4.jpg', '2019-04-18 08:35:41', '1'),
(3, 'image-2019-04-04.jpg', '2019-04-18 08:35:41', '1'),
(4, 'BEE-1096-Fashion_Banners_01_preview41.jpg', '2019-04-18 08:38:14', '1'),
(5, 'download.jpg', '2019-04-18 10:48:23', '1'),
(6, 'image5.jpg', '2019-04-18 10:48:23', '1'),
(7, '23.jpg', '2019-04-18 11:03:11', '1'),
(8, '1339-303.jpg', '2019-04-18 11:03:11', '1'),
(9, 'download1.jpg', '2019-04-18 11:03:11', '1');

-- --------------------------------------------------------

--
-- Table structure for table `table_employee`
--

CREATE TABLE `table_employee` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_employee`
--

INSERT INTO `table_employee` (`id`, `name`, `phone`, `email`, `status`) VALUES
(1, 'Jhon', '9999999999', 'jhon@gmail.com', 'Active'),
(2, 'smith', '8888888888', 'smith@gmail.com', 'Active'),
(3, 'Jhon', '9999999999', 'jhon@gmail.com', 'Active'),
(4, 'smith', '8888888888', 'smith@gmail.com', 'Active'),
(5, 'Jhon', '9999999999', 'jhon@gmail.com', 'Active'),
(6, 'smith', '8888888888', 'smith@gmail.com', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `table_employee_address`
--

CREATE TABLE `table_employee_address` (
  `id` int(255) NOT NULL,
  `emp_id` varchar(255) NOT NULL,
  `employee_postal_address` varchar(255) NOT NULL,
  `employee_permanent_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_employee_address`
--

INSERT INTO `table_employee_address` (`id`, `emp_id`, `employee_postal_address`, `employee_permanent_address`) VALUES
(1, '1', 'New York', 'California'),
(2, '2', 'London', 'UK');

-- --------------------------------------------------------

--
-- Table structure for table `table_employee_department`
--

CREATE TABLE `table_employee_department` (
  `id` int(255) NOT NULL,
  `emp_id` varchar(255) NOT NULL,
  `department_title` varchar(255) NOT NULL,
  `department_manager` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_employee_department`
--

INSERT INTO `table_employee_department` (`id`, `emp_id`, `department_title`, `department_manager`) VALUES
(1, '1', 'HR', 'ABC'),
(2, '2', 'IT', 'XYZ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_employee`
--
ALTER TABLE `table_employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_employee_address`
--
ALTER TABLE `table_employee_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_employee_department`
--
ALTER TABLE `table_employee_department`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `table_employee`
--
ALTER TABLE `table_employee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `table_employee_address`
--
ALTER TABLE `table_employee_address`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `table_employee_department`
--
ALTER TABLE `table_employee_department`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
